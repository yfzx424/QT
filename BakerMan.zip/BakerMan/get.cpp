#include "get.h"

Get::Get():QObject()
{
        this->m_netMan=new QNetworkAccessManager();
        this->m_netReq=new QNetworkRequest();
        this->m_url=new QString();
   // *(this->m_url)="http://qq305185957.gotoip3.com//WebService/APPWebService.ashx";
  //  QObject::connect(this->m_netMan,SIGNAL(finished(QNetworkReply*)),this,SLOT(ReceivedData(QNetworkReply*)));

}
void Get::GetData(QString reqstr)
{
    QByteArray bytearr;
    bytearr.append(reqstr);
    QUrl url;
    url.setUrl(*(this->m_url));
    this->m_netReq->setUrl(url);
    this->m_netMan->post(*(this->m_netReq),bytearr);
}
Get::~Get()
{
    delete this->m_netMan;
    delete this->m_netReq;
    delete this->m_url;
}
