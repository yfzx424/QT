#ifndef GET_H
#define GET_H

#include <QObject>
#include<QString>
#include<QNetworkAccessManager>
#include<QNetworkReply>
#include<QNetworkRequest>
class Get:public QObject
{
   Q_OBJECT

protected:
    QString * m_url;
    QNetworkAccessManager * m_netMan;
    QNetworkRequest * m_netReq;
    //数据请求，传入一个post字符串 键=值&键=值
    void virtual GetData(QString reqstr);
public slots:
      virtual void ReceivedData(QNetworkReply *reply)=0;
public:
    Get();
   //纯虚函数（请求完成后处理，解析，发送一个信号(json)到外部）
  virtual  ~Get();
};

#endif // GET_H
