#ifndef SUBMITQUESTION_H
#define SUBMITQUESTION_H

#include"get.h"
class submitQuestion : public Get
{
    Q_OBJECT
public:
    submitQuestion();
    //uid,前四个是 问题id，后四个是 答案1 or 0
Q_INVOKABLE void doSubmit(int uid,int wum,int q1,int q2,int q3,int q4,int q5,int a1,int a2,int a3,int a4,int a5);
 public slots:
    void ReceivedData(QNetworkReply * reply);
signals:
    void sigqml(QString str);
};

#endif // SUBMITQUESTION_H
