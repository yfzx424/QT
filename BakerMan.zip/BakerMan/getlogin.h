#ifndef GETLOGIN_H
#define GETLOGIN_H

#include<get.h>
///登录
class getLogin : public Get
{
    Q_OBJECT
protected:
  //  void GetData(QString reqstr);
public:
    getLogin();
   Q_INVOKABLE  void doLogin(QString name,QString pwd);
public slots:
   //返回槽
   void ReceivedData(QNetworkReply * reply);
signals:
   //发送到QML页面 的json数据包(所有信号名首字母小写)
   void received(QString str);
};

#endif // GETLOGIN_H
