#ifndef GETINFO_H
#define GETINFO_H

#include<get.h>
///获取学生信息
class getinfo : public Get
{
    Q_OBJECT
protected:
    ///内部post
    //void GetData(QString reqstr);
public:
    getinfo();
    //外部接口
Q_INVOKABLE   void  getUserData(int id);
public slots:
   //返回槽
   void ReceivedData(QNetworkReply * reply);
signals:
   //发送到QML页面 的json数据包
   void received(QString str);

};

#endif // GETINFO_H
