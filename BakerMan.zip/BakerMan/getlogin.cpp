#include "getlogin.h"
#include<QDomDocument>
#include<QDomElement>
#include<QDomNode>
#include<QJsonArray>
#include<QJsonObject>
#include<QJsonDocument>
getLogin::getLogin():Get()
{
    *(this->m_url)="http://qq305185957.gotoip3.com//WebService/APPWebService.ashx";
    QObject::connect(this->m_netMan,SIGNAL(finished(QNetworkReply*)),this,SLOT(ReceivedData(QNetworkReply*)));

}

void getLogin::doLogin(QString name, QString pwd)
{
    QString datastr="Cmd=Q0002&Xml=<?xml version=\"1.0\" encoding=\"UTF-8\"?><root><uid>"+name+"</uid><pass>"+pwd+"</pass></root>";
    this->GetData(datastr);
}
void getLogin::ReceivedData(QNetworkReply *reply)
{
    QString str;
    QString code;
    QString mess;
    QString uid;
    QString stuid;
    QDomNodeList tmpList;
    str=reply->readAll();
    QDomDocument doc;
    doc.setContent(str);
    QDomElement root=doc.documentElement();
    tmpList=root.elementsByTagName("code");
    code=tmpList.at(0).toElement().text();
    tmpList=root.elementsByTagName("mess");
    mess=tmpList.at(0).toElement().text();
    tmpList=root.elementsByTagName("uid");
    uid=tmpList.at(0).toElement().text();
    tmpList=root.elementsByTagName("stuid");
    stuid=tmpList.at(0).toElement().text();
    //////上面是解析xml，下面是创建json对象 返回str
    QJsonObject jsonobj;
    jsonobj.insert("code",code);
    jsonobj.insert("mess",mess);
    jsonobj.insert("uid",uid);
    jsonobj.insert("stuid",stuid);
    QJsonDocument jsondoc;
    jsondoc.setObject(jsonobj);
    QString jsonstr=jsondoc.toJson();
    qDebug()<<"这是json:"+jsonstr;
    emit received(jsonstr);
}
