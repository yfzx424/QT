#ifndef ANSWERQUESTION_H
#define ANSWERQUESTION_H
#include<get.h>
///获取问题（每日答题）
class answerQuestion:public Get
{
    Q_OBJECT
public:
    answerQuestion();
    //传入uid  quid quid是问题分类id html是9 深入.net是8
Q_INVOKABLE    void getQuestsions(int uid,int qid);
public slots:
      virtual void ReceivedData(QNetworkReply *reply);
 signals:
    void receivedqml(QString str);
};

#endif // ANSWERQUESTION_H
