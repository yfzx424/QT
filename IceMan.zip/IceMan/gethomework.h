#ifndef GETHOMEWORK_H
#define GETHOMEWORK_H

#include<get.h>
///获取作业信息
class getHomeWork : public Get
{
    Q_OBJECT
public slots:
      virtual void ReceivedData(QNetworkReply *reply);
public:
  Q_INVOKABLE   void dogetHomeWork(int id);
    getHomeWork();
signals:
   //发送到QML页面 的json数据包
   void received(QString str);
};

#endif // GETHOMEWORK_H
