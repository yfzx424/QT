#include "hanstorage.h"
#include<QFile>
#include<QByteArray>
#include<QString>
#include<QDataStream>
#include<qiodevice.h>
HanStorage::HanStorage():QObject()
{

}
void HanStorage::SaveNamePwd(QString name, QString pwd)
{
    QFile f("./data.dat");
    if(f.exists())f.remove();
    f.open(QIODevice::WriteOnly);
    int ms=MS;
    QDataStream ds(&f);
    ds<<ms<<name<<pwd;
    f.close();
}
bool HanStorage::isSaved()
{
    QFile f("./data.dat");
    if(!f.exists())return false;
    f.open(QIODevice::ReadOnly);
    QDataStream dts(&f);
    int ms;
    dts>>ms;
    if(ms!=MS)return false;
    return true;
}
QString HanStorage::readName()
{

    QFile f("./data.dat");
    f.open(QIODevice::ReadOnly);
    QDataStream dts(&f);
    int ms;
    QString name;
    QString pwd;
    dts>>ms>>name>>pwd;
    return name;
}
QString HanStorage::readPwd()
{
    QFile f("./data.dat");
    f.open(QIODevice::ReadOnly);
    QDataStream dts(&f);
    int ms;
    QString name;
    QString pwd;
    dts>>ms>>name>>pwd;
    return pwd;
}
void HanStorage::Clear()
{
     QFile f("./data.dat");
     if(f.exists())f.remove();
}
