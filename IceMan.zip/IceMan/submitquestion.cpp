#include "submitquestion.h"
#include<QDebug>
#include<QDomDocument>
#include<QDomElement>
#include<QDomNode>
#include<QJsonArray>
#include<QJsonObject>
#include<QJsonDocument>

submitQuestion::submitQuestion()
{
    *(this->m_url)="http://qq305185957.gotoip3.com//WebService/APPWebService.ashx";
    QObject::connect(this->m_netMan,SIGNAL(finished(QNetworkReply*)),this,SLOT(ReceivedData(QNetworkReply*)));
}

void submitQuestion::doSubmit(int uid,int wum, int q1, int q2, int q3, int q4,int q5, int a1, int a2, int a3, int a4,int a5)
{
    QString qstr=QString::number(q1)+","+QString::number(q2)+","+QString::number(q3)+","+QString::number(q4)+","+QString::number(q5);
    QString astr=QString::number(a1)+","+QString::number(a2)+","+QString::number(a3)+","+QString::number(a4)+","+QString::number(a5);
    QString datastr="Cmd=Q0008&Xml=<?xml version=\"1.0\" encoding=\"UTF-8\"?><root><stuid>"+QString::number(uid)+"</stuid><wnum>"+QString::number(wum)+"</wnum><qstr>"+qstr+"</qstr><astr>"+astr+"</astr></root>";
    qDebug()<<datastr;
 this->GetData(datastr);
}
void submitQuestion::ReceivedData(QNetworkReply *reply)
{
   // <?xml version="1.0" encoding="UTF-8"?><root><mess>加分完成</mess><code>1</code><mess>提交完成</mess></root>
    QString strxml=reply->readAll();
    qDebug()<<strxml;
    QDomDocument doc;
    doc.setContent(strxml);
    QDomNode root=doc.documentElement();
    QDomNodeList Codes=root.toElement().elementsByTagName("code");
    if(Codes.at(0).toElement().text()=="1")
      {

        emit sigqml("1");  //是否加分完成  都会返回1  具体看是否 wum 本地判断
    }else
    {
        emit sigqml("0");
    }
}
