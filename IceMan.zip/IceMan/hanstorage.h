#ifndef HANSTORAGE_H
#define HANSTORAGE_H
#include<QObject>
#define MS 95535  //魔术文字
///必须共有继承QObject
/// 本地存储
class HanStorage:public QObject
{
    Q_OBJECT
public:
    HanStorage();
    //存账号密码
 Q_INVOKABLE   void SaveNamePwd(QString name,QString pwd);
    //检测是否存有账号密码
 Q_INVOKABLE bool isSaved();
    //读取账号
 Q_INVOKABLE QString readName();
    //读取密码
 Q_INVOKABLE QString readPwd();
    //清空
 Q_INVOKABLE void Clear();
};

#endif // HANSTORAGE_H
