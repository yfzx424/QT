#include "getqiandao.h"
#include<QDomDocument>
#include<QDomElement>
#include<QDomNode>
#include<QJsonArray>
#include<QJsonObject>
#include<QJsonDocument>
getQiandao::getQiandao():Get()
{
    *(this->m_url)="http://qq305185957.gotoip3.com//WebService/APPWebService.ashx";
    QObject::connect(this->m_netMan,SIGNAL(finished(QNetworkReply*)),this,SLOT(ReceivedData(QNetworkReply*)));
}
void getQiandao::doQianDao(int id)
{
       QString strxml="Cmd=Q0004&Xml=<?xml version=\"1.0\" encoding=\"UTF-8\"?><root><stuid>"+QString::number(id)+"</stuid></root>";
       this->GetData(strxml);
}
void getQiandao::ReceivedData(QNetworkReply *reply)
{
    QString str;
    QString code;
    QString mess;

    QDomNodeList tmpList;
    str=reply->readAll();
    QDomDocument doc;
    doc.setContent(str);
    QDomElement root=doc.documentElement();
    tmpList=root.elementsByTagName("code");
    code=tmpList.at(0).toElement().text();
    tmpList=root.elementsByTagName("mess");
    mess=tmpList.at(0).toElement().text();
    //////上面是解析xml，下面是创建json对象 返回str
    QJsonObject jsonobj;
    jsonobj.insert("code",code);
    jsonobj.insert("mess",mess);
    QJsonDocument jsondoc;
    jsondoc.setObject(jsonobj);
    QString jsonstr=jsondoc.toJson();
    qDebug()<<"这是json:"+jsonstr;
    emit received(jsonstr);
}
