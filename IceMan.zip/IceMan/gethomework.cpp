#include "gethomework.h"
#include<QDebug>
#include<QDomDocument>
#include<QDomElement>
#include<QDomNode>
#include<QJsonArray>
#include<QJsonObject>
#include<QJsonDocument>
getHomeWork::getHomeWork()
{
     *(this->m_url)="http://qq305185957.gotoip3.com//WebService/APPWebService.ashx";
     QObject::connect(this->m_netMan,SIGNAL(finished(QNetworkReply*)),this,SLOT(ReceivedData(QNetworkReply*)));

}
void getHomeWork::dogetHomeWork(int id)
{
    QString xmldata="Cmd=Q0006&Xml=<?xml version=\"1.0\" encoding=\"UTF-8\"?><root><stuid>"+QString::number(id)+"</stuid></root>";
    this->GetData(xmldata);
}
void getHomeWork::ReceivedData(QNetworkReply *reply)
{
    //先转QString
    QString str=reply->readAll();

    QString code;
    QString mess;
    QString addtime;
    QString kemu;
    QString point;
    QString about;
    QDomNodeList tmpList;


    QDomDocument doc;
    doc.setContent(str);
    QDomElement root=doc.documentElement();
    tmpList=root.elementsByTagName("code");
    code=tmpList.at(0).toElement().text();
    tmpList=root.elementsByTagName("mess");
    mess=tmpList.at(0).toElement().text();
    tmpList=root.elementsByTagName("addtime");
    addtime=tmpList.at(0).toElement().text();
    tmpList=root.elementsByTagName("kemu");
    kemu=tmpList.at(0).toElement().text();
    tmpList=root.elementsByTagName("point");
    point=tmpList.at(0).toElement().text();
    tmpList=root.elementsByTagName("about");
    about=tmpList.at(0).toElement().text();
    //////上面是解析xml，下面是创建json对象 返回str
    QJsonObject jsonobj;
    jsonobj.insert("code",code);
    jsonobj.insert("mess",mess);
    jsonobj.insert("addtime",addtime);
    jsonobj.insert("kemu",kemu);
    jsonobj.insert("point",point);
    jsonobj.insert("about",about);
    QJsonDocument jsondoc;
    jsondoc.setObject(jsonobj);
    QString jsonstr=jsondoc.toJson();
    qDebug()<<"这是json:"+jsonstr;
    emit  received(jsonstr);
}
