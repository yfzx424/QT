# StuMan
用C++ Qt+ QML帮老师做的一个学生管理系统，简易