#include "answerquestion.h"
#include<QDebug>
#include<QDomDocument>
#include<QDomElement>
#include<QDomNode>
#include<QJsonArray>
#include<QJsonObject>
#include<QJsonDocument>
answerQuestion::answerQuestion():Get()
{
    *(this->m_url)="http://qq305185957.gotoip3.com//WebService/APPWebService.ashx";
    QObject::connect(this->m_netMan,SIGNAL(finished(QNetworkReply*)),this,SLOT(ReceivedData(QNetworkReply*)));
}
void answerQuestion::ReceivedData(QNetworkReply *reply)
{
    QString str=reply->readAll();
    //调试查看xml
    qDebug()<<str;
    QDomDocument doc;
    doc.setContent(str);
    QDomElement elem=doc.documentElement();
    QDomNodeList code=elem.elementsByTagName("code");
    if(code.at(0).toElement().text()=="0") //您已经答题了(这个bug是后来补上去的)
    {
        //直接发送信号 直接结束
        emit  receivedqml("[]");
        return;

    }
    QDomNodeList Missions=elem.elementsByTagName("mission");
    QJsonArray JsonArray;
    QDomNodeList tmpNodes;

    for(int i=0;i<=Missions.length();i++)
    {
       tmpNodes=Missions.at(i).toElement().elementsByTagName("answer");
       QJsonObject tmpAnserJson;
       QJsonArray tmparray;
       for(int k=0;k<tmparray.count();k++)tmparray.removeAt(k);
       tmpAnserJson.insert("title",Missions.at(i).toElement().attributeNode("title").value());
        tmpAnserJson.insert("mid",Missions.at(i).toElement().attributeNode("mid").value());
        for(int j=0;j<tmpNodes.length();j++)
        {
            QJsonObject tmpjsonObj;
            tmpjsonObj.insert("answer",tmpNodes.at(j).toElement().text());
            tmpjsonObj.insert("result",tmpNodes.at(j).toElement().attributeNode("result").value());
            tmpjsonObj.insert("aid",tmpNodes.at(j).toElement().attributeNode("aid").value());
            tmparray.append(tmpjsonObj);
        }
        tmpAnserJson.insert("detail",tmparray);
        JsonArray.append(tmpAnserJson);
    }
    QJsonDocument jsondoc;
    jsondoc.setArray(JsonArray);
    QString strjson=jsondoc.toJson();
    qDebug()<<strjson;
    emit receivedqml(strjson);
}
void answerQuestion::getQuestsions(int uid,int qid)
{
    QString xmlstr="Cmd=Q0007&Xml=<?xml version=\"1.0\" encoding=\"UTF-8\"?><root><stuid>"+QString::number(uid)+"</stuid><kid>"+QString::number(qid)+"</kid></root>";
    this->GetData(xmlstr);
}
