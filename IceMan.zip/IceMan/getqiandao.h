#ifndef GETQIANDAO_H
#define GETQIANDAO_H

#include<get.h>
//签到
class getQiandao : public Get
{
    Q_OBJECT
public:
    getQiandao();
public slots:
   //返回槽
   void ReceivedData(QNetworkReply * reply);
 Q_INVOKABLE   void doQianDao(int id);
signals:
   //发送到QML页面 的json数据包
   void received(QString str);
};

#endif // GETQIANDAO_H
