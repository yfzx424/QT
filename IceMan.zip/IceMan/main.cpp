#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include<getlogin.h> //登录
#include<getinfo.h> //获取信息
#include"hanstorage.h"
int main(int argc, char *argv[])
{
    QCoreApplication::setAttribute(Qt::AA_EnableHighDpiScaling);
    QGuiApplication app(argc, argv);
    QQmlApplicationEngine engine;
    qmlRegisterType<getLogin>("Han.Login",1,0,"Login");  //所有标签首字母大写
    qmlRegisterType<getinfo>("Han.Info",1,0,"Info");
    qmlRegisterType<HanStorage>("Han.Storage",1,0,"Storage");
    engine.load(QUrl(QLatin1String("qrc:/main.qml")));

    return app.exec();
}
