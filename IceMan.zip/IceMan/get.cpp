#include "get.h"

Get::Get():QObject()
{
        this->m_netMan=new QNetworkAccessManager();
        this->m_netReq=new QNetworkRequest();
        this->m_url=new QString();


}
void Get::GetData(QString reqstr)
{
    QByteArray bytearr;
    bytearr.append(reqstr);
    QUrl url;
    url.setUrl(*(this->m_url));
    this->m_netReq->setUrl(url);
    this->m_netMan->post(*(this->m_netReq),bytearr);
}
Get::~Get()
{
    delete this->m_netMan;
    delete this->m_netReq;
    delete this->m_url;
}
