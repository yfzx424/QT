#include "getinfo.h"
#include<qdebug.h>
#include<QUrl>
#include<QDebug>
#include<QDomDocument>
#include<QDomElement>
#include<QDomNode>
#include<QJsonArray>
#include<QJsonObject>
#include<QJsonDocument>
getinfo::getinfo():Get()
{
    *(this->m_url)="";
    QObject::connect(this->m_netMan,SIGNAL(finished(QNetworkReply*)),this,SLOT(ReceivedData(QNetworkReply*)));

}

void getinfo::getUserData(int id)
{

    QString reqstr="";
    GetData(reqstr);
}
void getinfo::ReceivedData(QNetworkReply *reply)
{
    QString str;
    QString name;
    QString cname;
    QString gname;
    QString point;
    QString cj;
    QDomNodeList tmpList;
    str=reply->readAll();
    QDomDocument doc;
    doc.setContent(str);
    QDomElement root=doc.documentElement();
    tmpList=root.elementsByTagName("name");
    name=tmpList.at(0).toElement().text();
    tmpList=root.elementsByTagName("cname");
    cname=tmpList.at(0).toElement().text();
    tmpList=root.elementsByTagName("gname");
    gname=tmpList.at(0).toElement().text();
    tmpList=root.elementsByTagName("point");
    point=tmpList.at(0).toElement().text();
    tmpList=root.elementsByTagName("cj");
    cj=tmpList.at(0).toElement().text();
    //////上面是解析xml，下面是创建json对象 返回str
    QJsonObject jsonobj;
    jsonobj.insert("name",name);
    jsonobj.insert("cname",cname);
    jsonobj.insert("gname",gname);
    jsonobj.insert("point",point);
    jsonobj.insert("cj",cj);
    QJsonDocument jsondoc;
    jsondoc.setObject(jsonobj);
    QString jsonstr=jsondoc.toJson();
    qDebug()<<"这是json:"+jsonstr;
    emit received(jsonstr);
}
